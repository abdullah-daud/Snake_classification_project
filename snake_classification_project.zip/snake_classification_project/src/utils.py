import json
from pathlib import Path
import numpy as np
import tensorflow as tf

IMG_SIZE = (224, 224)

def load_class_names(path="models/class_names.json"):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"class_names.json not found at {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_class_names(class_names, path="models/class_names.json"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(class_names, f, indent=4)

def preprocess_image(image, target_size=IMG_SIZE):
    # Preprocess a PIL image for model prediction.
    if image.mode != "RGB":
        image = image.convert("RGB")

    image = image.resize(target_size)
    image_array = np.array(image).astype("float32") / 255.0
    image_array = np.expand_dims(image_array, axis=0)
    return image_array

def load_model(model_path="models/snake_classifier.h5"):
    model_path = Path(model_path)
    if not model_path.exists():
        raise FileNotFoundError(f"Model not found at {model_path}")
    return tf.keras.models.load_model(model_path)
