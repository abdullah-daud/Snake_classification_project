from pathlib import Path
import shutil
from PIL import Image
import splitfolders
from utils import save_class_names

RAW_DIR = Path("dataset/raw")
PROCESSED_DIR = Path("dataset/processed")
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

def clean_invalid_images(raw_dir=RAW_DIR):
    removed = 0

    for image_path in raw_dir.rglob("*"):
        if image_path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue

        try:
            with Image.open(image_path) as img:
                img.verify()
        except Exception:
            image_path.unlink()
            removed += 1

    print(f"Removed invalid images: {removed}")

def get_class_names(raw_dir=RAW_DIR):
    class_names = sorted([
        folder.name for folder in raw_dir.iterdir()
        if folder.is_dir()
    ])
    return class_names

def split_dataset(raw_dir=RAW_DIR, output_dir=PROCESSED_DIR):
    if not raw_dir.exists():
        raise FileNotFoundError("dataset/raw folder not found. Please add your dataset first.")

    if output_dir.exists():
        shutil.rmtree(output_dir)

    splitfolders.ratio(
        input=str(raw_dir),
        output=str(output_dir),
        seed=42,
        ratio=(0.7, 0.2, 0.1),
        group_prefix=None,
        move=False
    )

    print("Dataset split completed.")
    print(f"Train path: {output_dir / 'train'}")
    print(f"Validation path: {output_dir / 'val'}")
    print(f"Test path: {output_dir / 'test'}")

def main():
    clean_invalid_images()
    class_names = get_class_names()
    if len(class_names) < 2:
        raise ValueError("At least two snake species folders are required.")

    save_class_names(class_names)
    split_dataset()

    print("Class names saved:")
    for class_name in class_names:
        print(f"- {class_name}")

if __name__ == "__main__":
    main()
