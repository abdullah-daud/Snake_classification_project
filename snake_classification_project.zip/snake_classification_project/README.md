# Snake Species Classification System

This project is a deep-learning-only Snake Species Classification System.

## Features
- Image preprocessing: resize, normalize, train/validation/test split
- Data augmentation: rotation, flip, zoom, shift, brightness
- Transfer learning using MobileNetV2
- Evaluation using accuracy, precision, recall, F1-score, and confusion matrix
- Streamlit app for snake image upload and species prediction
- Ready for Hugging Face Spaces deployment

## Dataset Format

Place your original dataset here:

```text
dataset/raw/
  Cobra/
    image1.jpg
    image2.jpg
  Python/
    image1.jpg
  Viper/
    image1.jpg
```

Each folder name is treated as one snake species/class.

## Project Structure

```text
snake_classification_project/
  dataset/
    raw/
    processed/
  models/
  results/
  src/
    data_preprocessing.py
    train_model.py
    evaluate_model.py
    utils.py
  app.py
  requirements.txt
  README.md
```

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

## Step 2: Add Dataset

Put your images into `dataset/raw/` using class folders.

Example:

```text
dataset/raw/King Cobra/*.jpg
dataset/raw/Russell Viper/*.jpg
dataset/raw/Indian Python/*.jpg
```

## Step 3: Preprocess Dataset

```bash
python src/data_preprocessing.py
```

This creates:

```text
dataset/processed/train/
dataset/processed/val/
dataset/processed/test/
models/class_names.json
```

## Step 4: Train Model

```bash
python src/train_model.py
```

This creates:

```text
models/snake_classifier.h5
models/training_accuracy.png
models/training_loss.png
```

## Step 5: Evaluate Model

```bash
python src/evaluate_model.py
```

This creates:

```text
results/classification_report.txt
results/confusion_matrix.png
```

## Step 6: Run Streamlit App Locally

```bash
streamlit run app.py
```

## Step 7: Deploy on Hugging Face Spaces

1. Create a new Space on Hugging Face.
2. Select Streamlit as SDK.
3. Upload:
   - `app.py`
   - `requirements.txt`
   - `models/snake_classifier.h5`
   - `models/class_names.json`
   - `src/utils.py`
4. Commit the files.
5. Hugging Face will build and launch the app.

## Notes for Best Accuracy

- Use at least 200–500 images per snake species if possible.
- Keep dataset balanced.
- Remove duplicate, blurry, and wrong-label images.
- Start with frozen MobileNetV2, then fine-tune top layers.
- Use early stopping to avoid overfitting.
