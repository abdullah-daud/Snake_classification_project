import streamlit as st
from PIL import Image
import numpy as np
import pandas as pd
from src.utils import preprocess_image, load_model, load_class_names

st.set_page_config(
    page_title="Snake Species Classification",
    page_icon="🐍",
    layout="centered"
)

@st.cache_resource
def get_model():
    return load_model("models/snake_classifier.h5")

@st.cache_data
def get_class_names():
    return load_class_names("models/class_names.json")

def predict(image):
    model = get_model()
    class_names = get_class_names()

    processed_image = preprocess_image(image)
    predictions = model.predict(processed_image)[0]

    top_index = int(np.argmax(predictions))
    predicted_class = class_names[top_index]
    confidence = float(predictions[top_index])

    results_df = pd.DataFrame({
        "Species": class_names,
        "Confidence": predictions
    }).sort_values(by="Confidence", ascending=False)

    return predicted_class, confidence, results_df

st.title("🐍 Snake Species Classification System")
st.write(
    "Upload a snake image and the deep learning model will predict the snake species."
)

uploaded_file = st.file_uploader(
    "Upload snake image",
    type=["jpg", "jpeg", "png", "webp"]
)

if uploaded_file is not None:
    try:
        image = Image.open(uploaded_file).convert("RGB")

        st.subheader("Uploaded Image")
        st.image(image, caption="Input Snake Image", use_container_width=True)

        with st.spinner("Predicting snake species..."):
            predicted_class, confidence, results_df = predict(image)

        st.subheader("Prediction Result")
        st.success(f"Predicted Species: {predicted_class}")
        st.info(f"Confidence: {confidence * 100:.2f}%")

        st.subheader("Confidence Score for Each Species")
        display_df = results_df.copy()
        display_df["Confidence"] = (display_df["Confidence"] * 100).round(2)
        st.dataframe(display_df, use_container_width=True)

        st.bar_chart(results_df.set_index("Species")["Confidence"])

        st.warning(
            "Safety Note: This app is for educational classification only. "
            "Do not handle or approach snakes based on model predictions."
        )

    except Exception as e:
        st.error("Unable to process this image. Please upload a valid snake image.")
        st.exception(e)

else:
    st.info("Please upload an image to start prediction.")
